#pragma once

void helperPrintLargerSpacer();

void helperWait(double seconds);

int helperGenerateRandomInteger(int start, int end);